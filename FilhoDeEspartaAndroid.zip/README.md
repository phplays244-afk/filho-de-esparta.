# Filho de Esparta — projeto Android

Este projeto empacota o jogo HTML original em um app Android de tela cheia (WebView), em orientação horizontal.

## Gerar APK no Android Studio
1. Instale Android Studio e o Android SDK Platform 35.
2. Abra esta pasta (`FilhoDeEspartaAndroid`) no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug estará em `app/build/outputs/apk/debug/app-debug.apk`.

O arquivo `app/src/main/assets/index.html` é o jogo HTML original fornecido. Para mudar o jogo, substitua esse arquivo mantendo o nome.

Este projeto é um scaffold para compilação; o APK ainda precisa ser gerado pelo Android Studio/SDK.
